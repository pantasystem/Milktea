package jp.panta.misskeyandroidclient.model.notes

data class CreateReaction (val i: String, val noteId: String, val reaction: String)