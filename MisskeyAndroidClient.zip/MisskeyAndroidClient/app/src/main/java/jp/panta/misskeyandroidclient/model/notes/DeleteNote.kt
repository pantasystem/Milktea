package jp.panta.misskeyandroidclient.model.notes

data class DeleteNote(val i: String, val noteId: String)