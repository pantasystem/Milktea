package jp.panta.misskeyandroidclient.viewmodel.notes

import android.arch.lifecycle.ViewModel
import android.arch.lifecycle.ViewModelProvider
import jp.panta.misskeyandroidclient.model.notes.LiveNotePagingStore
import java.lang.IllegalArgumentException

class TimlineViewModelFactory(private val pagingCallBack: LiveNotePagingStore.CallBack, private val type: TimelineViewModel.Type) : ViewModelProvider.Factory{

    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if(modelClass == TimelineViewModel::class.java)
            return TimelineViewModel(pagingCallBack, type) as T

        throw IllegalArgumentException("error")
    }
}