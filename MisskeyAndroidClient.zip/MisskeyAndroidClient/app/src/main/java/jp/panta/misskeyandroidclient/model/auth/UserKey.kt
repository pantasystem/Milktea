package jp.panta.misskeyandroidclient.model.auth

import jp.panta.misskeyandroidclient.model.users.User

data class UserKey(val appSecret: String, val token: String)