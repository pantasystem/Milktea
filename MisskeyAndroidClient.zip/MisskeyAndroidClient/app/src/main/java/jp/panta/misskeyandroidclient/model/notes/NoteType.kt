package jp.panta.misskeyandroidclient.model.notes

enum class NoteType{
    HOME,
    LOCAL,
    SOCIAL,
    GLOBAL,
    SEARCH,
    SEARCH_HASH,
    USER
    //USER_PINは別
}