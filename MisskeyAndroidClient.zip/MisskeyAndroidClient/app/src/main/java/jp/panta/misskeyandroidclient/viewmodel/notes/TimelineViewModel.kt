package jp.panta.misskeyandroidclient.viewmodel.notes

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MediatorLiveData
import android.arch.lifecycle.ViewModel
import jp.panta.misskeyandroidclient.model.api.MisskeyAPI
import jp.panta.misskeyandroidclient.model.notes.LiveNotePagingStore
import jp.panta.misskeyandroidclient.model.notes.Note
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.lang.Exception

class TimelineViewModel(private val pagingCallBack: LiveNotePagingStore.CallBack, type: Type) : ViewModel(){
    enum class Type{
        HOME,
        LOCAL,
        SOCIAL,
        GLOBAL
    }

    val timeline: LiveData<List<PlaneNoteViewData>>

    private val baseUrl = "https://misskey.io/"
    private val retrofit =  Retrofit.Builder()
        .baseUrl(baseUrl)
        .addConverterFactory(GsonConverterFactory.create())
        .client(OkHttpClient.Builder().build())
        .build()

    private val misskeyAPI = retrofit.create(MisskeyAPI::class.java)
    private val i = "mExya1oBb6i1oA1j"


    private val mLivePagingStore = when(type){
        Type.HOME -> LiveNotePagingStore(i, misskeyAPI::homeTimeline, pagingCallBack)
        Type.LOCAL -> LiveNotePagingStore(i, misskeyAPI::localTimeline, pagingCallBack)
        Type.SOCIAL -> LiveNotePagingStore(i, misskeyAPI::hybridTimeline, pagingCallBack)
        Type.GLOBAL -> LiveNotePagingStore(i, misskeyAPI::globalTimeline, pagingCallBack)

    }

    init{
        val liveData = MediatorLiveData<List<PlaneNoteViewData>>()
        mLivePagingStore.setLiveData(liveData)
        timeline = liveData
    }


    fun loadNew(){
        mLivePagingStore.loadNew()
    }

    fun loadOld(){
        mLivePagingStore.loadOld()
    }

    fun loadInit(){
        mLivePagingStore.loadInit()
    }


}