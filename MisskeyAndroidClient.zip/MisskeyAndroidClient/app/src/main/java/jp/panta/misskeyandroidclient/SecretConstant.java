package jp.panta.misskeyandroidclient;

public abstract class SecretConstant {
    public static String i(){
        return "mExya1oBb6i1oA1j";
    }
}
