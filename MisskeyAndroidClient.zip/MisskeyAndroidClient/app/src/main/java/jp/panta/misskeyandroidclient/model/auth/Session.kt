package jp.panta.misskeyandroidclient.model.auth

import jp.panta.misskeyandroidclient.model.api.MisskeyAPI

data class Session(val token: String, val url: String)